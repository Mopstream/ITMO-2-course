#ifndef CPP_SOLUTION_EXPRESSION_H
#define CPP_SOLUTION_EXPRESSION_H

#include <string>
#include <map>
class expression {
public:
    virtual std::string prefix_form() = 0;
    virtual int eval(std::map<std::string, int> *mp) = 0;
    virtual ~expression() {};
};

class variable : public expression {
private:
    std::string _name;

public:
    variable(std::string &name) {
      _name = name;
    }

    virtual int eval(std::map<std::string, int> *mp){
        if (!(*mp).count(_name)) (*mp)[_name] = 0;
        return (*mp)[_name];
    }

    virtual std::string prefix_form() {
        return _name;
    }
};

class implication : public expression {
private:
    expression* _left;
    expression* _right;

public:
    implication(expression* left, expression* right) :
            _left(left),
            _right(right) {
    }

    virtual int eval(std::map<std::string, int> *mp){
        return _left->eval(mp) <= _right->eval(mp);
    }

    virtual std::string prefix_form() {
        return "(->," + _left->prefix_form() + "," + _right->prefix_form() + ")";
    }
};

class disjunction : public expression {
private:
    expression* _left;
    expression* _right;

public:
    disjunction(expression* left, expression* right) :
            _left(left),
            _right(right) {
    }

    virtual int eval(std::map<std::string, int> *mp){
        return _left->eval(mp) + _right->eval(mp) >= 1;
    }
    virtual std::string prefix_form() {
        return "(|," + _left->prefix_form() + "," + _right->prefix_form() + ")";
    }
};

class conjunction : public expression {
private:
    expression* _left;
    expression* _right;

public:
    conjunction(expression* left, expression* right) :
            _left(left),
            _right(right) {
    }

    virtual int eval(std::map<std::string, int> *mp){
        return _left->eval(mp) * _right->eval(mp) == 1;
    }

    virtual std::string prefix_form() {
        return "(&," + _left->prefix_form() + "," + _right->prefix_form() + ")";
    }
};

class negation : public expression {
private:
    expression* _expr;

public:
    negation(expression* expr) :
            _expr(expr) {
    }

    virtual int eval(std::map<std::string, int> *mp){
        return _expr->eval(mp) == 0;
    }
    virtual std::string prefix_form() {
        return "(!" + _expr->prefix_form() + ")";
    }
};

#endif //CPP_SOLUTION_EXPRESSION_H
