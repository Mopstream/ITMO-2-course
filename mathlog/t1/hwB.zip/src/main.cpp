#include <iostream>
#include "expression.h"
#include "parser/expression.tab.h"
#include "parser/expression.lexer.h"
#include <map>

using namespace std;

extern expression *result;

void yyerror(const char *error) {
    cerr << error;
}

int yywrap() {
    return 1;
}

int main() {
    map<string, int> mp;
    string expression;
    cin >> expression;
    yy_scan_string(expression.c_str());
    yyparse();
    int count = result->eval(&mp);
    int n = mp.size();
    for (int i = 1; i < 1 << n; i++) {
        auto it = mp.begin();
        for (int j = 0; it != mp.end(); it++, j++) {
            it->second = (i & (1 << j)) >> j;
        }
        count += result->eval(&mp);
    }
    if (!count) std::cout << "Unsatisfiable" << "\n";
    else if (count == (1 << n)) std::cout << "Valid" << "\n";
    else
        std::cout << "Satisfiable and invalid, " << count << " true and " << (1 << n) - count << " false cases" << "\n";
    return 0;
}
