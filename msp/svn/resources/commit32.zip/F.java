public class F extends null {

    double ee();

    Object gg();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int af() {
        return -1;
    }

    public long dd() {
        return 33;
    }
}
