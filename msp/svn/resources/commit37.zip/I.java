public class I extends null {

    String kk();

    int ae();

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public double ad() {
        return 9.11;
    }

    public Object rr() {
        return null;
    }

    public long ac() {
        return 333;
    }
}
