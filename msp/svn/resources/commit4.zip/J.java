public interface J {

    java.util.Set<Integer> ll();

    java.lang.Class qq();
}
