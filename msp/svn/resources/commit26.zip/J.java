public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }
}
