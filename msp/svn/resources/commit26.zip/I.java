public class I extends null {

    String kk();

    int ae();

    public java.lang.Class qq() {
        return getClass();
    }
}
