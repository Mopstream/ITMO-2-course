public class F extends null {

    double ee();

    Object gg();

    public int af() {
        return -1;
    }
}
