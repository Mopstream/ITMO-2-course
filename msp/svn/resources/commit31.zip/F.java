public interface F {

    double ee();

    Object gg();
}
