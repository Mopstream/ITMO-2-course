public class J extends null {

    java.util.Set<Integer> ll();

    java.lang.Class qq();

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public void ab() {
        System.out.println("\n");
    }

    public Object pp() {
        return this;
    }

    public Object rr() {
        return null;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
