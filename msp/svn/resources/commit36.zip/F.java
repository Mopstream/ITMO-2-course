public class F extends null {

    double ee();

    Object gg();

    public String kk() {
        return "Hello world";
    }

    public float ff() {
        return 3.14;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public void ab() {
        System.out.println("\n");
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
