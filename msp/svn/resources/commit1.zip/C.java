public class C implements I, F {

    private String a = "hello";

    private double c = 100.500;

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public int cc() {
        return 13;
    }

    public String kk() {
        return "Yes";
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public double ee() {
        return 0.000001;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public float ff() {
        return 0;
    }
}
