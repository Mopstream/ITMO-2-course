#include "hal.h"

unsigned int sw_num[] = {GPIO_PIN_4, GPIO_PIN_8, GPIO_PIN_10, GPIO_PIN_12};
unsigned int leds_num[] = {GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5,
                           GPIO_PIN_6, GPIO_PIN_8, GPIO_PIN_9,
                           GPIO_PIN_11, GPIO_PIN_12};

int DELAY = 500;
int delta = 100;
int frame = 0;


int mask[12][8] = {{1, 1, 1, 0, 0, 0, 1, 1},
                   {0, 1, 1, 1, 0, 1, 1, 0},
                   {0, 0, 1, 1, 1, 1, 0, 0},
                   {0, 0, 0, 1, 1, 1, 0, 0},
                   {0, 0, 1, 1, 1, 1, 1, 0},
                   {0, 1, 1, 0, 0, 1, 1, 1},
                   {1, 1, 0, 0, 1, 1, 1, 0},
                   {0, 1, 1, 1, 1, 1, 0, 0},
                   {0, 0, 1, 1, 1, 0, 0, 0},
                   {0, 1, 1, 1, 1, 0, 0, 0},
                   {0, 0, 0, 0, 1, 1, 0, 0},
                   {0, 0, 0, 0, 0, 1, 1, 0}};

int read_sw() {
    int res = 0;
    for (int i = 0; i < 4; ++i) {
        res += (2 ^ i) * HAL_GPIO_ReadPin(GPIOE, sw_num[i]);
    }
    return res;
}


void print_frame(int frame) {
    for (int i = 0; i < 8; ++i) {
        HAL_GPIO_WritePin(GPIOD, leds_num[i], mask[frame][i] ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }
}

void TIM6_IRQ_Handler() {
    __disable_irq();

    print_frame(frame);
    frame = (frame + 1) % 12;

    int sw_val = read_sw();
    WRITE_REG(TIM6_ARR, DELAY + sw_val * delta);

    __enable_irq();
}

int umain() {
    registerTIM6_IRQHandler(TIM6_IRQ_Handler);
    __enable_irq();

    WRITE_REG(TIM6_ARR, DELAY);
    WRITE_REG(TIM6_DIER, TIM_DIER_UIE);
    WRITE_REG(TIM6_PSC, 0);
    WRITE_REG(TIM6_CR1, TIM_CR1_CEN);

    return 0;
}