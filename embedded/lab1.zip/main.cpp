#include "hal.h"

#define Green GPIO_PIN_13
#define Yellow GPIO_PIN_14
#define Red GPIO_PIN_15
#define Btn_pin GPIO_PIN_15

unsigned int sw_num[] = {GPIO_PIN_4, GPIO_PIN_8, GPIO_PIN_10, GPIO_PIN_12};
unsigned int leds_num[] = {GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_5,
                           GPIO_PIN_6, GPIO_PIN_8, GPIO_PIN_9,
                           GPIO_PIN_11, GPIO_PIN_12};

int delay = 500;

void set_color(unsigned int color) {
    unsigned int colors[] = {Green, Yellow, Red};
    for (unsigned int c: colors) {
        if (c == color) {
            HAL_GPIO_WritePin(GPIOD, c, GPIO_PIN_SET);
        } else {
            HAL_GPIO_WritePin(GPIOD, c, GPIO_PIN_RESET);
        }
    }
}

bool check_sw() {
    GPIO_PinState states[4];
    for (int i = 0; i < 4; ++i) {
        states[i] = HAL_GPIO_ReadPin(GPIOE, sw_num[i]);
    }
    return (states[0] == GPIO_PIN_SET && states[1] == GPIO_PIN_RESET &&
            states[2] == GPIO_PIN_RESET && states[3] == GPIO_PIN_SET);
}

void btn_handle(bool *btn_pressed) {
    GPIO_PinState state = HAL_GPIO_ReadPin(GPIOC, Btn_pin);
    if (state == GPIO_PIN_RESET) {
        (*btn_pressed) ^= 1;
    }
}

void print_frame(int frame) {
    if (frame < 6) {
        for (int i = 0; i < 8; i++) {
            if (0 <= i - frame && i - frame <= 2) {
                HAL_GPIO_WritePin(GPIOD, leds_num[i], GPIO_PIN_SET);
            } else {
                HAL_GPIO_WritePin(GPIOD, leds_num[i], GPIO_PIN_RESET);
            }
        }
    } else {
        print_frame(10 - frame);
    }
}

void animation() {
    int frame = 0;
    bool btn_pressed = false;
    while (check_sw()) {
        if (!btn_pressed) {
            set_color(Green);
            print_frame(frame);
            frame = (frame + 1) % 10;
        }
        else {
            set_color(Red);
        }
        btn_handle(&btn_pressed);
        HAL_Delay(delay);
    }

}

int umain() {
    set_color(Yellow);
    while (true) {
        animation();
        set_color(Yellow);
        for (int i = 0; i < 4; i++) {
            GPIO_PinState state = HAL_GPIO_ReadPin(GPIOE, sw_num[i]);
            HAL_GPIO_WritePin(GPIOD, leds_num[i], state);
        }
        for (int i = 4; i < 8; i++) {
            HAL_GPIO_WritePin(GPIOD, leds_num[i], GPIO_PIN_RESET);
        }
    }
    return 0;
}